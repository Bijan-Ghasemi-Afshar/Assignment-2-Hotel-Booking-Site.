from flask import Flask, request, render_template

from datetime import datetime

## Source: http://stackoverflow.com/questions/2673385/how-to-generate-random-number-with-the-specific-length-in-python
from random import randint
##

import csv
app = Flask(__name__)


date_format = "%Y-%m-%d"

def readFile(aFile):
    with open(aFile, 'r') as inFile:
        reader = csv.reader(inFile)
        commentBook= [row for row in reader]
    return commentBook   


def writeFile(aList, aFile):
    with open(aFile, 'w', newline='') as outFile:
        writer = csv.writer(outFile)
        writer.writerows(aList)
    return     

## Source: http://stackoverflow.com/questions/2673385/how-to-generate-random-number-with-the-specific-length-in-python

def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)

############################################# 


@app.route('/')
def index():    
    return render_template('Index.html')
    
    
@app.route('/about us')
def about_us():    
    return render_template('About-Us.html')     

        
@app.route('/facilities')
def facilities():    
    return render_template('Facilities.html')


@app.route('/gallery')
def gallery():    
    return render_template('Gallery.html')


# A method to calculate the number of available rooms and suites by subtracting
# the number of rooms or suites in the booking request files from the total number of rooms or suites
def roomsNum():

# Total number of rooms and suites
    supRoom = 13
    delRoom = 9
    luxDobRoom = 10
    junSuite = 5
    stuSuite = 3
    delSuite = 5

    with open('static\\bookingRequests.csv', 'r') as inFile:
        reader = csv.reader(inFile)
        aList = list(reader)  

        counter = -1
        aListOfRooms = []
        rowNumbers = len(aList)
        if (aList != []):
            for row in aList:

                counter = counter + 1                   

                if (counter == rowNumbers):
                    break

                text = aList[counter][6]        

                aListOfRooms.append(text)    


# Calculating the number of available rooms and suites
            takenSupRoom = aListOfRooms.count('Superior Room')          
            supRoom = supRoom - takenSupRoom

            takenDelRoom = aListOfRooms.count('Deluxe Room')
            delRoom = delRoom - takenDelRoom

            takenLuxDobRoom = aListOfRooms.count('Luxury Double Room')
            luxDobRoom = luxDobRoom - takenLuxDobRoom

            takenJunSuite = aListOfRooms.count('Junior Suite')        
            junSuite = junSuite - takenJunSuite

            takenStuSuite = aListOfRooms.count('Studio Suite')
            stuSuite = stuSuite - takenStuSuite

            takenDelSuite = aListOfRooms.count('Deluxe Suite')
            delSuite = delSuite - takenDelSuite

        return supRoom, delRoom, luxDobRoom, junSuite, stuSuite, delSuite


@app.route('/rooms')
def rooms():    
    
    supRoom, delRoom, luxDobRoom, junSuite, stuSuite, delSuite = roomsNum()
                            
    return render_template('Rooms.html', supRoom=supRoom, delRoom=delRoom,
     luxDobRoom=luxDobRoom, junSuite=junSuite, stuSuite=stuSuite, delSuite=delSuite)


@app.route('/activities')
def activities():    
    return render_template('Activities.html')


@app.route('/atrractions')
def atrractions():    
    return render_template('Atrractions.html')


@app.route('/contact us')
def contact_us():    
    return render_template('Contact-Us.html')   


@app.route('/comments')    
def comments():
    with open('static\\comments.csv', 'r') as inFile:
        reader = csv.reader(inFile)
        aList= [row for row in reader]        
        aList.reverse()        
    return render_template("Comments.html", aList= aList)
    
    
    
@app.route('/booking form')    
def bookingForm():
    return render_template('Booking.html')  


@app.route('/booking request send', methods=['post'])    
def bookingRequestSend():

    bookingRequestsFile= 'static\\bookingRequests.csv'
    bookingRequestsBook= readFile(bookingRequestsFile)
    
    firstName= request.form.get('firstName')
    surname = request.form.get('surname')
    email = request.form.get('email')
    phoneNumber = request.form.get('phoneNumber')
    arrival = request.form.get('arrival')
    departure = request.form.get('departure')
    room = request.form.get('room')

# A 'not confirmed' status and a random 4 digit number as a booking request ID is also generated     
    status = 'not confirmed'
    idNumber = random_with_N_digits(4)
    

# An error prevention for preventing the users to make an unfinished form
    if(firstName != '' and surname != '' and email != '' and phoneNumber != '' and arrival != '' and departure != '' and room != '-- Select a room --'):

        arrivalDate = datetime.strptime(arrival, date_format)
        departureDate = datetime.strptime(departure, date_format)
        datesDiffer = departureDate - arrivalDate 
        numberOfDays = datesDiffer.days

# Calculating the total cost of stay and checking for the availablity of the room or suite
# And checking the arrival and departure dates  
        superiorRoom, deluxeRoom, luxuryDoubleRoom, juniorSuite, studioSuite, deluxeSuite = roomsNum()


        if(room == 'Superior Room'):
            totalCost = 125 * numberOfDays
            if(totalCost < 0):
                error = 'Your departure date is before your arrival date'
                return render_template('Booking.html', error=error)
            if(superiorRoom == 0):                
                error = 'There is no Superior Room available'
                return render_template('Booking.html', error=error)

        if(room == 'Deluxe Room'):
            totalCost = 180 * numberOfDays
            if(totalCost < 0):
                error = 'Your departure date is before your arrival date'
                return render_template('Booking.html', error=error)
            if(deluxeRoom == 0):
                error = 'There is no Deluxe Room available'
                return render_template('Booking.html', error=error)
        
        if(room == 'Luxury Double Room'):
            totalCost = 250 * numberOfDays
            if(luxuryDoubleRoom == 0):
                error = 'There is no Luxury Double Room available'
                return render_template('Booking.html', error=error)

        if(room == 'Junior Suite'):
            totalCost = 300 * numberOfDays
            if(totalCost < 0):
                error = 'Your departure date is before your arrival date'
                return render_template('Booking.html', error=error)
            if(juniorSuite == 0):
                error = 'There is no Junior Suite available'
                return render_template('Booking.html', error=error)
 
        if(room == 'Studio Suite'):
            totalCost = 340 * numberOfDays
            if(totalCost < 0):
                error = 'Your departure date is before your arrival date'
                return render_template('Booking.html', error=error)
            if(studioSuite == 0):
                error = 'There is no Studio Suite available'
                return render_template('Booking.html', error=error)

        if(room == 'Deluxe Suite'):
            totalCost = 400 * numberOfDays
            if(totalCost < 0):
                error = 'Your departure date is before your arrival date'
                return render_template('Booking.html', error=error)
            if(deluxeSuite == 0):
                error = 'There is no Deluxe Suite available'
                return render_template('Booking.html', error=error)


        newEntry = [firstName, surname, email, phoneNumber, arrival, departure, room, idNumber, totalCost, status]        
        bookingRequestsBook.append(newEntry)
        writeFile(bookingRequestsBook, bookingRequestsFile)
    
    else:
        error = 'Not enough information has been given'
        return render_template('Booking.html', error=error)    


    return render_template('IdAndTotalCost.html', idNumber=idNumber, totalCost=totalCost)    


@app.route('/confirmed booking request')    
def confirmation():
    
    with open('static\\bookingRequests.csv', 'r') as inFile:
        reader = csv.reader(inFile)
        aList2 = list(reader)               
        aList = []        
        counter = -1                    
        rowNumbers = len(aList2)        

        for row in aList2:                                                                    
            counter = counter + 1      
           
            if (counter == rowNumbers):
                break            

            isConfirmed = aList2[counter][9]             

# Checking the booking request status 
# If it was confirmed it is going to be shown in the list
            if (isConfirmed == 'confirmed'):
                aList.append(row) 

            else:                 
                continue            

        return render_template('ConfirmedBookingRequests.html', aList= aList) 
                


@app.route('/comments', methods=['post'])
def addComment():
    commentFile= 'static\\comments.csv'
    commentBook= readFile(commentFile)

    name= request.form.get('name')
    comment = request.form.get('comment')
    date = datetime.now()    
    
    date = str(date.day) +'/'+  str(date.month)+'/'+ str(date.year) +' '+ str(date.hour)+':'+ str(date.minute)   

    if(name != '' and comment != ''):

        newEntry= [name, date, comment]
        commentBook.append(newEntry)
        writeFile(commentBook, commentFile)

        with open('static\\comments.csv', 'r') as inFile:
            reader = csv.reader(inFile)
            aList= [row for row in reader]
            aList.reverse()
        return render_template('Comments.html', aList= aList, commentBook=commentBook)    

    else:
        error = 'No comment has been left or no name'
        with open('static\\comments.csv', 'r') as inFile:
            reader = csv.reader(inFile)
            aList = [row for row in reader]     
            aList.reverse()       
        return render_template('Comments.html', error=error, aList= aList)

                        

if __name__ == '__main__':  
    app.debug = True
    app.run()